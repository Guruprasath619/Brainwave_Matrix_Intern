import requests
from bs4 import BeautifulSoup
import re
from flask import Flask , render_template ,request
import joblib
import asyncio
import aiohttp


# Placeholder function for find_phishing_links
def find_phishing_links(url):
    # Example logic to detect phishing links
    if "phish" in url or "fake" in url:
        return "Phishing link detected!"
    elif not url.startswith("http"):
        return "Invalid URL format!"
    else:
        return "URL seems safe."
    # flask created

    
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        url = request.form['url']
        phishing_links = find_phishing_links(url)
        return render_template('index.html', url=url, phishing_links=phishing_links)
    else:
        return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)